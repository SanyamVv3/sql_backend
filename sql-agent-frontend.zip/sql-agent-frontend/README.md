# SQL Agent Frontend

A modern React frontend for the SQL Agent application that allows users to upload databases and query them using natural language.

## Features

### 🚀 Core Functionality
- **File Upload**: Support for Excel files (.xlsx, .xls) and SQLite databases (.db, .sqlite, .sqlite3)
- **Drag & Drop**: Intuitive drag-and-drop interface for file uploads
- **Session Management**: Maintain multiple database sessions simultaneously
- **Natural Language Queries**: Query databases using plain English
- **Real-time Results**: Display query results and generated SQL

### 🎨 User Interface
- **Modern Design**: Clean, professional interface with gradient backgrounds
- **Responsive Layout**: Works seamlessly on desktop and mobile devices
- **Interactive Elements**: Hover effects, smooth transitions, and loading animations
- **Dark Mode Support**: Built-in dark mode compatibility
- **Accessibility**: ARIA labels, keyboard navigation, and screen reader support

### 🔧 Technical Features
- **Session Switching**: Dropdown to switch between uploaded databases
- **Progress Indicators**: Upload progress and query loading states
- **Error Handling**: User-friendly error messages and validation
- **File Validation**: Automatic file type validation before upload
- **Session Cleanup**: Delete sessions and clean up temporary files

## Architecture

### Component Structure
```
App.jsx (Main Component)
├── File Upload Section
│   ├── Drag & Drop Area
│   ├── File Selection Button
│   └── Session List
├── Query Interface Section
│   ├── Session Selector
│   ├── Query Input
│   └── Example Queries
└── Results Display Section
    ├── Generated SQL
    └── Query Results
```

### State Management
- **Sessions**: Array of active database sessions
- **Active Session**: Currently selected database
- **Upload State**: Progress and loading indicators
- **Query State**: Input, loading, and results
- **Error Handling**: Global error state management

## API Integration

The frontend integrates with the FastAPI backend through the following endpoints:

- `POST /upload-excel/` - Upload Excel files
- `POST /upload-database/` - Upload SQLite databases
- `POST /query/` - Execute natural language queries
- `GET /sessions/{session_id}/info` - Get session information
- `DELETE /sessions/{session_id}` - Clean up sessions

## Installation & Setup

### Prerequisites
- Node.js 20.x or higher
- pnpm package manager
- Backend API running on port 8000

### Installation
```bash
# Install dependencies
pnpm install

# Start development server
pnpm run dev --host

# Build for production
pnpm run build
```

### Environment Configuration
The frontend expects the backend API to be running on `http://localhost:8000`. To change this, update the `API_BASE_URL` constant in `src/App.jsx`.

## Usage

### 1. Upload Database
- Drag and drop an Excel or SQLite file onto the upload area
- Or click "Select File" to browse for files
- Wait for the upload to complete and session to be created

### 2. Query Database
- Select a database from the dropdown (if multiple are uploaded)
- Enter your question in natural language
- Click "Ask Question" or press Ctrl+Enter
- View the results and generated SQL query

### 3. Manage Sessions
- Switch between databases using the session dropdown
- View active sessions in the sidebar
- Delete sessions using the trash icon

## Example Queries

- "What tables are available in this database?"
- "Show me the first 5 rows of each table"
- "What are the column names and types?"
- "Find the total count of records"
- "Show me the top 10 customers by revenue"

## Technology Stack

- **React 19.x** - Frontend framework
- **Vite** - Build tool and development server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Modern UI component library
- **Lucide React** - Icon library
- **Axios** - HTTP client for API calls
- **Framer Motion** - Animation library (available)

## File Structure

```
src/
├── components/
│   └── ui/           # shadcn/ui components
├── assets/           # Static assets
├── App.jsx          # Main application component
├── App.css          # Global styles and Tailwind config
├── main.jsx         # Application entry point
└── index.css        # Base styles
```

## Styling

The application uses Tailwind CSS with a custom design system:

- **Color Palette**: Professional blue/indigo gradient theme
- **Typography**: Consistent font scales and weights
- **Spacing**: Systematic spacing using Tailwind's scale
- **Components**: shadcn/ui components for consistency
- **Responsive**: Mobile-first responsive design

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance Considerations

- **Lazy Loading**: Components are loaded on demand
- **Debounced Input**: Query input is debounced to prevent excessive API calls
- **Efficient Re-rendering**: React.memo used for optimization
- **Bundle Optimization**: Vite provides optimized production builds

## Security

- **File Validation**: Client-side file type validation
- **CORS Handling**: Proper CORS configuration for API calls
- **Error Boundaries**: Graceful error handling and recovery
- **Input Sanitization**: Safe handling of user input

## Development

### Available Scripts
- `pnpm run dev` - Start development server
- `pnpm run build` - Build for production
- `pnpm run preview` - Preview production build
- `pnpm run lint` - Run ESLint

### Development Guidelines
- Follow React best practices and hooks patterns
- Use TypeScript for type safety (if migrating)
- Maintain component modularity and reusability
- Write comprehensive tests for critical functionality

## Deployment

The application can be deployed to any static hosting service:

1. Build the application: `pnpm run build`
2. Deploy the `dist/` folder to your hosting service
3. Configure the backend API URL for production
4. Ensure CORS is properly configured on the backend

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is part of the SQL Agent application suite.

