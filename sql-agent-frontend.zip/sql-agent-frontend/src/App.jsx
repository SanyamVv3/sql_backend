import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Upload, Database, MessageSquare, FileText, Trash2, AlertCircle, CheckCircle, Loader2 } from 'lucide-react'
import axios from 'axios'
import './App.css'

const API_BASE_URL = 'http://localhost:8000'

function App() {
  const [sessions, setSessions] = useState([])
  const [activeSessionId, setActiveSessionId] = useState(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [query, setQuery] = useState('')
  const [isQuerying, setIsQuerying] = useState(false)
  const [queryResult, setQueryResult] = useState(null)
  const [error, setError] = useState(null)
  const [dragActive, setDragActive] = useState(false)

  // File upload handler
  const handleFileUpload = useCallback(async (file) => {
    if (!file) return

    const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls')
    const isDatabase = file.name.endsWith('.db') || file.name.endsWith('.sqlite') || file.name.endsWith('.sqlite3')

    if (!isExcel && !isDatabase) {
      setError('Please upload an Excel file (.xlsx, .xls) or SQLite database (.db, .sqlite, .sqlite3)')
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setError(null)

    const formData = new FormData()
    formData.append('file', file)

    try {
      const endpoint = isExcel ? '/upload-excel/' : '/upload-database/'
      const response = await axios.post(`${API_BASE_URL}${endpoint}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          setUploadProgress(progress)
        },
      })

      const newSession = {
        sessionId: response.data.session_id,
        filename: file.name,
        status: 'active',
        uploadedAt: new Date(),
        message: response.data.message
      }

      setSessions(prev => [...prev, newSession])
      setActiveSessionId(newSession.sessionId)
      setUploadProgress(100)
      
      setTimeout(() => {
        setIsUploading(false)
        setUploadProgress(0)
      }, 1000)

    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to upload file')
      setIsUploading(false)
      setUploadProgress(0)
    }
  }, [])

  // Drag and drop handlers
  const handleDrag = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }, [handleFileUpload])

  // Query handler
  const handleQuery = useCallback(async () => {
    if (!query.trim() || !activeSessionId) return

    setIsQuerying(true)
    setError(null)

    try {
      const response = await axios.post(`${API_BASE_URL}/query/`, {
        query: query.trim(),
        session_id: activeSessionId
      })

      setQueryResult(response.data)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to execute query')
    } finally {
      setIsQuerying(false)
    }
  }, [query, activeSessionId])

  // Session deletion handler
  const handleDeleteSession = useCallback(async (sessionId) => {
    try {
      await axios.delete(`${API_BASE_URL}/sessions/${sessionId}`)
      setSessions(prev => prev.filter(s => s.sessionId !== sessionId))
      
      if (activeSessionId === sessionId) {
        const remainingSessions = sessions.filter(s => s.sessionId !== sessionId)
        setActiveSessionId(remainingSessions.length > 0 ? remainingSessions[0].sessionId : null)
        setQueryResult(null)
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to delete session')
    }
  }, [activeSessionId, sessions])

  const activeSession = sessions.find(s => s.sessionId === activeSessionId)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            SQL Agent
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Query your databases using natural language
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20">
            <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
            <AlertDescription className="text-red-800 dark:text-red-200">
              {error}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* File Upload Section */}
          <div className="lg:col-span-1">
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="h-5 w-5" />
                  Upload Database
                </CardTitle>
                <CardDescription>
                  Upload Excel files or SQLite databases
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                    dragActive
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  {isUploading ? (
                    <div className="space-y-3">
                      <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-500" />
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Uploading... {uploadProgress}%
                      </p>
                      <Progress value={uploadProgress} className="w-full" />
                    </div>
                  ) : (
                    <>
                      <Database className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                        Drag & drop files here, or click to select
                      </p>
                      <Input
                        type="file"
                        accept=".xlsx,.xls,.db,.sqlite,.sqlite3"
                        onChange={(e) => handleFileUpload(e.target.files[0])}
                        className="hidden"
                        id="file-upload"
                      />
                      <Button
                        onClick={() => document.getElementById('file-upload').click()}
                        variant="outline"
                        className="w-full"
                      >
                        Select File
                      </Button>
                    </>
                  )}
                </div>

                {/* Session List */}
                {sessions.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                      Active Sessions
                    </h3>
                    <div className="space-y-2">
                      {sessions.map((session) => (
                        <div
                          key={session.sessionId}
                          className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                            session.sessionId === activeSessionId
                              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                              : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                          }`}
                        >
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                              {session.filename}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {session.uploadedAt.toLocaleTimeString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={session.sessionId === activeSessionId ? 'default' : 'secondary'}>
                              {session.sessionId === activeSessionId ? 'Active' : 'Idle'}
                            </Badge>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteSession(session.sessionId)}
                              className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Query and Results Section */}
          <div className="lg:col-span-2">
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Query Interface
                </CardTitle>
                <CardDescription>
                  {activeSession 
                    ? `Ask questions about ${activeSession.filename}`
                    : 'Upload a database to start querying'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Session Selector */}
                {sessions.length > 1 && (
                  <div className="mb-4">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                      Select Database
                    </label>
                    <Select value={activeSessionId || ''} onValueChange={setActiveSessionId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a database..." />
                      </SelectTrigger>
                      <SelectContent>
                        {sessions.map((session) => (
                          <SelectItem key={session.sessionId} value={session.sessionId}>
                            {session.filename}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Query Input */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                      Your Question
                    </label>
                    <Textarea
                      placeholder={
                        activeSession
                          ? "Ask anything about your data... e.g., 'Show me the top 10 customers by revenue'"
                          : "Upload a database first to start querying"
                      }
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      disabled={!activeSession}
                      className="min-h-[100px]"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                          handleQuery()
                        }
                      }}
                    />
                  </div>
                  
                  <Button
                    onClick={handleQuery}
                    disabled={!activeSession || !query.trim() || isQuerying}
                    className="w-full"
                  >
                    {isQuerying ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Processing...
                      </>
                    ) : (
                      'Ask Question'
                    )}
                  </Button>
                </div>

                {/* Example Queries */}
                {activeSession && !queryResult && (
                  <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Example Questions:
                    </h4>
                    <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                      <p>• "What tables are available in this database?"</p>
                      <p>• "Show me the first 5 rows of each table"</p>
                      <p>• "What are the column names and types?"</p>
                      <p>• "Find the total count of records"</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Results Section */}
            {queryResult && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Query Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* SQL Query Display */}
                    {queryResult.sql_query && (
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Generated SQL:
                        </h4>
                        <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                          <code className="text-sm text-gray-800 dark:text-gray-200">
                            {queryResult.sql_query}
                          </code>
                        </div>
                      </div>
                    )}

                    <Separator />

                    {/* Result Display */}
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Answer:
                      </h4>
                      <div className="bg-white dark:bg-gray-900 p-4 rounded-lg border">
                        <pre className="whitespace-pre-wrap text-sm text-gray-800 dark:text-gray-200 font-mono">
                          {queryResult.result}
                        </pre>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-sm text-gray-500 dark:text-gray-400">
          <p>Upload your Excel files or SQLite databases and query them using natural language</p>
        </div>
      </div>
    </div>
  )
}

export default App

